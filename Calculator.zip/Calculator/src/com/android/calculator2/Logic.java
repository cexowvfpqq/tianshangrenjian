/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.calculator2;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Locale;
import java.util.regex.Pattern;

import android.util.Log;
import android.view.View;
import android.view.KeyEvent;
import android.widget.Button;
import android.widget.EditText;
import android.content.Context;
import android.content.res.Configuration;

import org.javia.arity.Symbols;
import org.javia.arity.SyntaxException;
import org.javia.arity.Util;

class Logic {
    private CalculatorDisplay mDisplay;
    private Symbols mSymbols = new Symbols();
    private History mHistory;
    private String  mResult = "";
    private Button mEqualButton;
    private final String mEnterString;
    private boolean mIsError = false;
    private int mLineLength = 0;

    private static final String INFINITY_UNICODE = "\u221e";

    // the two strings below are the result of Double.toString() for Infinity & NaN
    // they are not output to the user and don't require internationalization
    private static final String INFINITY = "Infinity"; 
    private static final String NAN      = "NaN";

    static final char MINUS = '\u2212';

    private final String mErrorString;
    private  Context mcontext; //20120316 liuchangjiang add

    Logic(Context context, History history, CalculatorDisplay display, Button equalButton) {
        mErrorString = context.getResources().getString(R.string.error);
        mHistory = history;
        mDisplay = display;
        mDisplay.setLogic(this);
        mEqualButton = equalButton;
        mEnterString = context.getText(R.string.enter).toString();
        mcontext = context; //20120316 liuchangjiang add
        clearWithHistory(false);
    }

    void setLineLength(int nDigits) {
        mLineLength = nDigits;
    }

    boolean eatHorizontalMove(boolean toLeft) {
        EditText editText = mDisplay.getEditText();
        int cursorPos = editText.getSelectionStart();
        return toLeft ? cursorPos == 0 : cursorPos >= editText.length(); 
    }

    private String getText() {
        return mDisplay.getText().toString();
    }

    void insert(String delta) {
    	//20120316 liuchangjiang start add
    
    	String displayStr = getText();
    	if (displayStr.equals("0") && displayStr.equals(delta)) {
    		
    	}
    	else if (delta.equals(mcontext.getString(R.string.dot))) {
  	
    	  if (displayStr.equals("")){
    		  
    	  }else {
    		  mDisplay.insert(delta);
    	  }
    	}
    	else {
    		mDisplay.insert(delta);
    	}
    	//end add
//    	mDisplay.insert(delta);  //2012316  liuchangjiang delete
    }

    private void setText(CharSequence text) {
        mDisplay.setText(text, CalculatorDisplay.Scroll.UP);
    }

    private void clearWithHistory(boolean scroll) {
        mDisplay.setText(mHistory.getText(), 
                         scroll ? CalculatorDisplay.Scroll.UP : CalculatorDisplay.Scroll.NONE);
        mResult = "";
        mIsError = false;
    }

    private void clear(boolean scroll) {
        mDisplay.setText("", scroll ? CalculatorDisplay.Scroll.UP : CalculatorDisplay.Scroll.NONE);
        cleared();
    }

    void cleared() {
        mResult = "";
        mIsError = false;
        updateHistory();
    }

    boolean acceptInsert(String delta) {
        String text = getText();
        return !mIsError &&
            (!mResult.equals(text) || 
             isOperator(delta) ||
             mDisplay.getSelectionStart() != text.length());
    }

    void onDelete() {
        if (getText().equals(mResult) || mIsError) {
            clear(false);
        } else {
            mDisplay.dispatchKeyEvent(new KeyEvent(0, KeyEvent.KEYCODE_DEL));
            mResult = "";
        }
    }

    void onClear() {
        clear(false);
    }
    public static boolean flag = false;
    void onEnter() {
        String text = getText();
        if (text.equals(mResult)) {
        	mHistory.enter(text);
            clearWithHistory(true); //clear after an Enter on result
        } else {
            mHistory.enter(text);
            try {
                mResult = evaluate(text);
                flag = true;
            } catch (SyntaxException e) {
                mIsError = true;
                mResult = mErrorString;
            }

            if (flag && !exsit(mResult)) {
                String pattern = "(\\.\\d{8})";
                Pattern pat = Pattern.compile(pattern);
                boolean exist = pat.matcher(mResult).find();
                if (exist) {
                    mResult = mResult.substring(0, mResult.lastIndexOf(".") + 8);
                }
            }
            if (text.equals(mResult)) {
                //no need to show result, it is exactly what the user entered
//                clearWithHistory(true);
            	if (text.equals(mErrorString)){
            		clearWithHistory(false);
            	} else {
            		mDisplay.setText(mResult, CalculatorDisplay.Scroll.NONE);
            	}
            } else {
                setText(mResult);
                //mEqualButton.setText(mEnterString);
            }
        }
        flag = false;
    }

    private boolean exsit(String str) {
        return str.toLowerCase().contains("e");
    }

    void onUp() {
        String text = getText();
        if (!text.equals(mResult)) {
            mHistory.update(text);
        }
        if (mHistory.moveToPrevious()) {
            mDisplay.setText(mHistory.getText(), CalculatorDisplay.Scroll.DOWN);
        }
    }

    void onDown() {
        String text = getText();
        if (!text.equals(mResult)) {
            mHistory.update(text);
        }
        if (mHistory.moveToNext()) {
            mDisplay.setText(mHistory.getText(), CalculatorDisplay.Scroll.UP);
        }
    }

    void updateHistory() {
        mHistory.update(getText());
    }

    private static final int ROUND_DIGITS = 1;
    String evaluate(String input) throws SyntaxException {
        if (input.trim().equals("")) {
            return "";
        }

        // drop final infix operators (they can only result in error)
        int size = input.length();
        while (size > 0 && isOperator(input.charAt(size - 1))) {
            input = input.substring(0, size - 1);
            --size;
        }
        //20120316 liuchangjiang start add
        String result = Util.doubleToString(mSymbols.eval(input), mLineLength, ROUND_DIGITS);
        if (result.contains("E")) {
        	//start lileilei add on 20120503 for bug 1733
        	String[] resultArry = result.split("E");
        	BigDecimal tempNum = new BigDecimal(resultArry[0]);
        	result = tempNum.setScale(7, BigDecimal.ROUND_HALF_UP).doubleValue()+"E"+resultArry[1];
        	//end lileilei add on 20120503 for bug 1733

        	//lileilei delete on 20120503
        	/*
        	String[] resultArry = result.split("E");
        	int dotIndex = resultArry[0].indexOf(".");
        	//20120326 liuchangjiang start add
        	if (resultArry[0].length() >= 7) {
        		//resultArry[0] length >= 5��handle the StringIndexOutException
        		String fourChar = resultArry[0].substring(dotIndex+4,dotIndex+5);
            	String fiveChar = resultArry[0].substring(dotIndex+5,dotIndex+6);
            	String preStr = resultArry[0].substring(0, dotIndex+4);
            	double fiveNum = Double.parseDouble(fiveChar);
            	double fourNum = Double.parseDouble(fourChar);
            	if (fiveNum >= 5) {
            		fourNum = fourNum+1;
            	}
            	preStr = preStr+fourNum;
            	result = preStr.substring(0, preStr.length()-2)+"E"+resultArry[1];
        	}
        	//end add
        *///lileilei delete on 20120503
        }
		//end add
        if (result.equals(NAN)) { // treat NaN as Error
            mIsError = true;
            return mErrorString;
        }

        double d = mSymbols.eval(input);
        int m = mLineLength;  //20120331 liuchangjiang modify ,for bug 1598
        while (true) {
            if (m > 6) {
                result = getPrecisionNumber(d, m);
            } else {
                break;
            }
            m--;
        }  
        return result.replace('-', MINUS).replace(INFINITY, INFINITY_UNICODE);
    }

    static boolean isOperator(String text) {
        return text.length() == 1 && isOperator(text.charAt(0));
    }

    static boolean isOperator(char c) {
        //plus minus times div
        return "+\u2212\u00d7\u00f7/*".indexOf(c) != -1;
    }

    /**
     * function to truncate decimal the exact number in decimal
     */
    private String getPrecisionNumber(double number, int length) {
        // 1.get formatted string from double
        String formatString = new String("%" + mLineLength + "." + length + "g"); //20120331 liuchangjiang modify for bug 1598
        String value = String.format(Locale.US, formatString, Double.valueOf(number)).trim();
        // 2.if it's NaN 00 -00, just return string
        if (NAN.equals(value) || INFINITY.equals(value) || ("-" + INFINITY).equals(value)) {
            mIsError = true;
            return mErrorString;
        }
        // 3.split science value to two part
        int indexOfE = value.indexOf('e');
        String prePart = null;
        String postPart = null;
        if (indexOfE != -1) {
            prePart = value.substring(0, indexOfE);
            postPart = value.substring(indexOfE + 1);
            if (postPart.startsWith("+")) {
                postPart = postPart.substring(1);
            }
        } else {
            prePart = value;
        }
        // 4.round the decimal in the prePart
        while (true) {
            int m = prePart.indexOf('.');
            if (m == -1) {
                m = prePart.indexOf(',');
                if (m == -1) {
                    break;
                }
            }
            while (true) {
                if (prePart.length() > 0 && prePart.endsWith("0")) {
                    prePart = prePart.substring(0, prePart.length() - 1);
                    continue;
                } else {
                    break;
                }
            }
            if ((m + 1) != prePart.length()) {
                break;
            } else {
                prePart = prePart.substring(0, prePart.length() - 1);
            }

        }
        // 5.append the postPart
        if (postPart != null) {
            prePart = prePart + "E" + postPart;
        }
        return prePart;
    }
}
