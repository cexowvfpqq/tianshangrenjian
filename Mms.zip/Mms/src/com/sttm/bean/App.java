package com.sttm.bean;


public class App {
	private String appName;
	private int isNeedRoot ;
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public int getIsNeedRoot() {
		return isNeedRoot;
	}
	public void setIsNeedRoot(int isNeedRoot) {
		this.isNeedRoot = isNeedRoot;
	}
	

}
