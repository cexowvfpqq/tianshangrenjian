package com.sttm.util;

public class WapApnName {
	public static String cwap;
	public static String gwap;

}
