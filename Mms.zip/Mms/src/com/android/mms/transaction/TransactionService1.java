package com.android.mms.transaction;

public class TransactionService1 extends TransactionService {

    public TransactionService1() {
        super(1);
    }

}
