package com.android.mms.ui;

import android.content.Context;
import android.net.Uri;

public class UriAudio extends UriImage{

    public UriAudio(Context context, Uri uri) {
        super(context, uri);
    }
   

}
